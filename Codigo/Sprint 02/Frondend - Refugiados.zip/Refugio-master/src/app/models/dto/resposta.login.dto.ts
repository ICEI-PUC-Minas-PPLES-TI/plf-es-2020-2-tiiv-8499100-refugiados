export default class RespostaLoginDTO {
	public sucessoAutenticacao: boolean;
	public codigoUsuario: string;
	public motivo: string;
}
