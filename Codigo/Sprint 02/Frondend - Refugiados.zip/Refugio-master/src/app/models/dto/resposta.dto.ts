export default class RespostaDTO {
  public sucesso: boolean;
  public mensagem: string;
  public corpo: any;
}
