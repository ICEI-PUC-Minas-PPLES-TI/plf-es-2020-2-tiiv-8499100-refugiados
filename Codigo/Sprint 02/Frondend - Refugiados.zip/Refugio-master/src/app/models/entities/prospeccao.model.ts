import { TipoUsuario } from './../enums/tipo-usuario';

export class Prospeccao {
  nome: string;
  email: string;
  tipoUsuario: TipoUsuario;
}
