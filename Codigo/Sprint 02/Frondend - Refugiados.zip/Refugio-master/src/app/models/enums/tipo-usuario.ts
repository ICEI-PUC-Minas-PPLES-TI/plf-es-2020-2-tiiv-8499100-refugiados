export enum TipoUsuario {
  EMPRESA = 'Empresa',
  COLABORADOR = 'Empresa',
}
